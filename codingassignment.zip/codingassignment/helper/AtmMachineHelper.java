package codingassignment.helper;

import codingassignment.model.AtmMachineDenomination;
import codingassignment.model.CurrencyNotes;

public class AtmMachineHelper {

    public boolean validateRequestedAmount(final int accountBalance, final int requestedAmount) {
        if (requestedAmount < 10) {
            System.out.println("Transaction denied! Please enter a value greater than 10$.");
            return false;
        }
        if (requestedAmount > 5000) {
            System.out.println("Transaction denied! This atm has an withdrawal limit of 5000$.");
            return false;
        }
        if (requestedAmount % 10 != 0) {
            System.out.println("Transaction denied! This atm can dispense money only in multiples of 10.");
            return false;
        }
        if (requestedAmount > accountBalance) {
            System.out.println("Transaction denied! Requested amount is greater than available balance.");
            return false;
        }
        return true;        // returns true if all the validations are passed
    }

    public CurrencyNotes dispenseBankNotes(final int accountBalance, int requestedAmount, final AtmMachineDenomination atmMachineDenomination) {
        int hundredsBillCnt = 0, fiftiesBillCnt = 0, twentiesBillCnt = 0, tensBillCnt = 0;
        CurrencyNotes currencyNotes = new CurrencyNotes();

        // hundreds bill
        if (requestedAmount >= 100) {
            hundredsBillCnt = (requestedAmount / 100);

            synchronized (AtmMachineDenomination.class) {
                if (hundredsBillCnt <= atmMachineDenomination.getHundredsBillCnt()) {
                    currencyNotes.setHundredsBillCnt(hundredsBillCnt);
                    requestedAmount = requestedAmount - (100 * hundredsBillCnt);
                    atmMachineDenomination.updatedHundredsBillCnt(hundredsBillCnt);
                } else {
                    currencyNotes.setHundredsBillCnt(atmMachineDenomination.getHundredsBillCnt());
                    requestedAmount = requestedAmount - (100 * atmMachineDenomination.getHundredsBillCnt());
                    atmMachineDenomination.updatedHundredsBillCnt(atmMachineDenomination.getHundredsBillCnt());
                }
            }
        }

        // fifties bill
        if (requestedAmount >= 50) {
            fiftiesBillCnt = (requestedAmount / 50);

            synchronized (AtmMachineDenomination.class) {
                if (fiftiesBillCnt <= atmMachineDenomination.getFiftiesBillCnt()) {
                    currencyNotes.setFiftiesBillCnt(fiftiesBillCnt);
                    requestedAmount = requestedAmount - (50 * fiftiesBillCnt);
                    atmMachineDenomination.updatedFiftiesBillCnt(fiftiesBillCnt);
                } else {
                    currencyNotes.setFiftiesBillCnt(atmMachineDenomination.getFiftiesBillCnt());
                    requestedAmount = requestedAmount - (50 * atmMachineDenomination.getFiftiesBillCnt());
                    atmMachineDenomination.updatedFiftiesBillCnt(atmMachineDenomination.getFiftiesBillCnt());
                }
            }
        }

        // twenties bill
        if (requestedAmount >= 20) {
            twentiesBillCnt = (requestedAmount / 20);

            synchronized (AtmMachineDenomination.class) {
                if (twentiesBillCnt <= atmMachineDenomination.getTwentiesBillCnt()) {
                    currencyNotes.setTwentiesBillCnt(twentiesBillCnt);
                    requestedAmount = requestedAmount - (20 * twentiesBillCnt);
                    atmMachineDenomination.updatedTwentiesBillCnt(twentiesBillCnt);
                } else {
                    currencyNotes.setTwentiesBillCnt(atmMachineDenomination.getTwentiesBillCnt());
                    requestedAmount = requestedAmount - (20 * atmMachineDenomination.getTwentiesBillCnt());
                    atmMachineDenomination.updatedTwentiesBillCnt(atmMachineDenomination.getTwentiesBillCnt());
                }
            }
        }

        // tens bill
        if (requestedAmount >= 10) {
            tensBillCnt = (requestedAmount / 10);

            synchronized (AtmMachineDenomination.class) {
                if (tensBillCnt <= atmMachineDenomination.getTensBillCnt()) {
                    currencyNotes.setTensBillCnt(tensBillCnt);
                    requestedAmount = requestedAmount - (10 * tensBillCnt);
                    atmMachineDenomination.updatedTensBillCnt(tensBillCnt);
                } else {
                    currencyNotes.setTensBillCnt(atmMachineDenomination.getTensBillCnt());
                    requestedAmount = requestedAmount - (10 * atmMachineDenomination.getTensBillCnt());
                    atmMachineDenomination.updatedTensBillCnt(atmMachineDenomination.getTensBillCnt());
                }
            }
        }

        if (requestedAmount == 0) {
            currencyNotes.setNotesDispenseSuccessFlg(true);
        }
        return currencyNotes;
    }
}
