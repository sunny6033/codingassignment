package codingassignment.model;

public class AtmMachineDenomination {
    private volatile int hundredsBillCnt = 10;
    private volatile int fiftiesBillCnt = 10;
    private volatile int twentiesBillCnt = 10;
    private volatile int tensBillCnt = 10;

    public synchronized int getHundredsBillCnt() {
        return hundredsBillCnt;
    }

    public synchronized void updatedHundredsBillCnt(final int withdrawnHundredsCnt) {
        hundredsBillCnt = hundredsBillCnt - withdrawnHundredsCnt;
    }

    public synchronized int getFiftiesBillCnt() {
        return fiftiesBillCnt;
    }

    public synchronized void updatedFiftiesBillCnt(final int withdrawnFiftiesCnt) {
        fiftiesBillCnt = fiftiesBillCnt - withdrawnFiftiesCnt;
    }

    public synchronized int getTwentiesBillCnt() {
        return twentiesBillCnt;
    }

    public synchronized void updatedTwentiesBillCnt(final int withdrawnTwentiesCnt) {
        twentiesBillCnt = twentiesBillCnt - withdrawnTwentiesCnt;
    }

    public synchronized int getTensBillCnt() {
        return tensBillCnt;
    }

    public synchronized void updatedTensBillCnt(final int withdrawnTensBillCnt) {
        tensBillCnt = tensBillCnt - withdrawnTensBillCnt;
    }
}
