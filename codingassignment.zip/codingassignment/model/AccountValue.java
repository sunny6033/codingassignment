package codingassignment.model;

public class AccountValue {
    private int balance = 0;

    public int getBalance() {
        return balance;
    }

    public void topUp(final int amt) {
        balance += amt;
    }

//    public void debit(final int amt) {
//        balance -= amt;
//    }

    @Override
    public String toString() {
        return "AccountValue{" +
                "balance=" + balance +
                '}';
    }
}
