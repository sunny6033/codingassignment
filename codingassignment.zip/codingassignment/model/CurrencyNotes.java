package codingassignment.model;

public class CurrencyNotes {
    private int hundredsBillCnt;
    private int fiftiesBillCnt;
    private int twentiesBillCnt;
    private int tensBillCnt;
    boolean notesDispenseSuccessFlg = Boolean.FALSE;

    public int getHundredsBillCnt() {
        return hundredsBillCnt;
    }

    public void setHundredsBillCnt(int hundredsBillCnt) {
        this.hundredsBillCnt = hundredsBillCnt;
    }

    public int getFiftiesBillCnt() {
        return fiftiesBillCnt;
    }

    public void setFiftiesBillCnt(int fiftiesBillCnt) {
        this.fiftiesBillCnt = fiftiesBillCnt;
    }

    public int getTwentiesBillCnt() {
        return twentiesBillCnt;
    }

    public void setTwentiesBillCnt(int twentiesBillCnt) {
        this.twentiesBillCnt = twentiesBillCnt;
    }

    public int getTensBillCnt() {
        return tensBillCnt;
    }

    public void setTensBillCnt(int tensBillCnt) {
        this.tensBillCnt = tensBillCnt;
    }

    public boolean isNotesDispenseSuccessFlg() {
        return notesDispenseSuccessFlg;
    }

    public void setNotesDispenseSuccessFlg(boolean notesDispenseSuccessFlg) {
        this.notesDispenseSuccessFlg = notesDispenseSuccessFlg;
    }

    @Override
    public String toString() {
        return "CurrencyNotes{" +
                "hundredsBillCnt=" + hundredsBillCnt +
                ", fiftiesBillCnt=" + fiftiesBillCnt +
                ", twentiesBillCnt=" + twentiesBillCnt +
                ", tensBillCnt=" + tensBillCnt +
                ", notesDispenseSuccessFlg=" + notesDispenseSuccessFlg +
                '}';
    }
}
