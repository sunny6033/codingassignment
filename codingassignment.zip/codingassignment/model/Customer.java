package codingassignment.model;

public class Customer {
    private String name;
    private String accountNumber;
    private AccountValue account;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(final String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public AccountValue getAccount() {
        return account;
    }

    public void setAccount(final AccountValue account) {
        this.account = account;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", account=" + account +
                '}';
    }
}
