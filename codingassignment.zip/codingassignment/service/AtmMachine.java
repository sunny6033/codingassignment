package codingassignment.service;

import codingassignment.helper.AtmMachineHelper;
import codingassignment.model.AccountValue;
import codingassignment.model.AtmMachineDenomination;
import codingassignment.model.CurrencyNotes;

public class AtmMachine {
    private AtmMachineDenomination atmMachineDenomination;
    private AtmMachineHelper atmMachineHelper;

    public AtmMachine(final AtmMachineDenomination atmMachineDenomination, final AtmMachineHelper atmMachineHelper) {
        this.atmMachineDenomination = atmMachineDenomination;
        this.atmMachineHelper = atmMachineHelper;
    }

    public void cashWithdrawl(final AccountValue account, final int requestedAmount) {

        // validate the requested amount
        boolean isRequestedAmtValidFlg = atmMachineHelper.validateRequestedAmount(account.getBalance(), requestedAmount);

        if (isRequestedAmtValidFlg) {

            // Try to dispense the requested amount
            CurrencyNotes currencyNotes = atmMachineHelper.dispenseBankNotes(account.getBalance(), requestedAmount, atmMachineDenomination);

            System.out.println("Is notes dispense possible for :: " + Thread.currentThread().getName() + " -- " + currencyNotes.isNotesDispenseSuccessFlg());

            if (!currencyNotes.isNotesDispenseSuccessFlg()) {
                System.out.println("Transaction denied! Not enough money to dispense in this ATM.");
            } else {
                System.out.println("100$ bills : " + currencyNotes.getHundredsBillCnt());
                System.out.println("50$ bills : " + currencyNotes.getFiftiesBillCnt());
                System.out.println("20$ bills : " + currencyNotes.getTwentiesBillCnt());
                System.out.println("10$ bills : " + currencyNotes.getTensBillCnt());
            }
        }
    }
}
