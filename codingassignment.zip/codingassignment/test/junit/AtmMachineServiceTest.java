package codingassignment.test.junit;

import codingassignment.helper.AtmMachineHelper;
import codingassignment.model.AccountValue;
import codingassignment.model.CurrencyNotes;
import codingassignment.service.AtmMachine;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class AtmMachineServiceTest {

    @InjectMocks
    private AtmMachine atmMachine;

    @Mock
    private AtmMachineHelper atmMachineHelper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void cashWithdrawlTest() {
        AccountValue account = new AccountValue();
        account.topUp(2000);
        int requestedAmount = 200;
        CurrencyNotes currencyNotes = new CurrencyNotes();
        currencyNotes.setNotesDispenseSuccessFlg(true);

        Mockito.when(atmMachineHelper.validateRequestedAmount(Mockito.anyInt(), Mockito.anyInt())).thenReturn(true);
        Mockito.when(atmMachineHelper.dispenseBankNotes(Mockito.anyInt(), Mockito.anyInt(), Mockito.any())).thenReturn(currencyNotes);
        atmMachine.cashWithdrawl(account, requestedAmount);
        verify(atmMachineHelper, times(1)).validateRequestedAmount(Mockito.anyInt(), Mockito.anyInt());
        verify(atmMachineHelper, times(1)).dispenseBankNotes(Mockito.anyInt(), Mockito.anyInt(), Mockito.any());
    }

    @Test
    public void cashWithdrawlValidationFailureTest() {
        AccountValue account = new AccountValue();
        account.topUp(2000);
        int requestedAmount = 2200;

        Mockito.when(atmMachineHelper.validateRequestedAmount(Mockito.anyInt(), Mockito.anyInt())).thenReturn(false);
        atmMachine.cashWithdrawl(account, requestedAmount);
        verify(atmMachineHelper, times(1)).validateRequestedAmount(Mockito.anyInt(), Mockito.anyInt());
        verify(atmMachineHelper, times(0)).dispenseBankNotes(Mockito.anyInt(), Mockito.anyInt(), Mockito.any());
    }
}
