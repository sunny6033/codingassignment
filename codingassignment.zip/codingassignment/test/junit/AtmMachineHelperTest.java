package codingassignment.test.junit;

import codingassignment.helper.AtmMachineHelper;
import codingassignment.model.AtmMachineDenomination;
import codingassignment.model.CurrencyNotes;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class AtmMachineHelperTest {

    @InjectMocks
    private AtmMachineHelper atmMachineHelper;

    @Test
    public void validateRequestedAmountTest() {
        int accountBalance = 2000;
        int requestedAmount = 1500;
        boolean isRequestedAmtValidFlg = atmMachineHelper.validateRequestedAmount(accountBalance, requestedAmount);
        assertEquals(true, isRequestedAmtValidFlg);
    }

    @Test
    public void validateRequestedAmountNegativeTest() {
        int accountBalance = 2000;
        int requestedAmount = 2100;
        boolean isRequestedAmtValidFlg = atmMachineHelper.validateRequestedAmount(accountBalance, requestedAmount);
        assertEquals(false, isRequestedAmtValidFlg);
    }

    @Test
    public void validateRequestedAmountNotMultipleOfTen() {
        int accountBalance = 2000;
        int requestedAmount = 109;
        boolean isRequestedAmtValidFlg = atmMachineHelper.validateRequestedAmount(accountBalance, requestedAmount);
        assertEquals(false, isRequestedAmtValidFlg);
    }

    @Test
    public void validateRequestedAmountLessThanTen() {
        int accountBalance = 2000;
        int requestedAmount = 9;
        boolean isRequestedAmtValidFlg = atmMachineHelper.validateRequestedAmount(accountBalance, requestedAmount);
        assertEquals(false, isRequestedAmtValidFlg);
    }

    @Test
    public void dispenseBankNotesTest() {
        int accountBalance = 2000;
        int requestedAmount = 170;
        CurrencyNotes currencyNotes = atmMachineHelper.dispenseBankNotes(accountBalance, requestedAmount, new AtmMachineDenomination());
        assertEquals(true, currencyNotes.isNotesDispenseSuccessFlg());
        assertEquals(1, currencyNotes.getHundredsBillCnt());
        assertEquals(1, currencyNotes.getFiftiesBillCnt());
        assertEquals(1, currencyNotes.getTwentiesBillCnt());
        assertEquals(0, currencyNotes.getTensBillCnt());
    }

    @Test
    public void dispenseBankNotesNegativeTest() {
        int accountBalance = 2000;
        int requestedAmount = 1820;
        CurrencyNotes currencyNotes = atmMachineHelper.dispenseBankNotes(accountBalance, requestedAmount, new AtmMachineDenomination());
        assertEquals(false, currencyNotes.isNotesDispenseSuccessFlg());
    }
}
