package codingassignment.test;

import codingassignment.helper.AtmMachineHelper;
import codingassignment.model.AccountValue;
import codingassignment.model.AtmMachineDenomination;
import codingassignment.model.Customer;
import codingassignment.service.AtmMachine;

public class AtmWithdrawMultiThreadingTest {

    public static void main(String[] args) {
        Customer c1 = new Customer();
        c1.setName("John");
        c1.setAccountNumber("1234567");
        AccountValue account1 = new AccountValue();
        account1.topUp(2000);
        c1.setAccount(account1);

        Customer c2 = new Customer();
        c2.setName("Miller");
        c2.setAccountNumber("7654321");
        AccountValue account2 = new AccountValue();
        account2.topUp(2000);
        c2.setAccount(account2);

        AtmMachine atm = new AtmMachine(new AtmMachineDenomination(), new AtmMachineHelper());

        Thread t1 = new Thread(() -> {
            atm.cashWithdrawl(c1.getAccount(), 1700);
        });
        t1.setName("customer 1");

        Thread t2 = new Thread(() -> {
            atm.cashWithdrawl(c2.getAccount(), 730);
        });
        t2.setName("customer 2");

        t1.start();
        t2.start();
    }
}
